package tetris;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Tetris2 {
  
  private static GameForm2 gf;
//  private static StartupUI sf;
  private static StartupForm sf;
  private static LeaderboardForm lf;
  
  private static AudioPlayer audio = new AudioPlayer();

  public static void start()
  {
    gf.setVisible(true);
    gf.startGame();
  }

  public static void showLeaderBoard()
  {
    lf.setVisible(true);
  }

  public static void showStartup()
  {
    sf.setVisible(true);
  }

  public static void bothGameOver(int p1, int p2, int score1, int score2)
  {
      if(p1 == 1 && p2 == 1)
      {
          gameOver(score1 , score2);
      }
      else
      {
          return;
      }
  }
//  public static void gameOver()
//  {
//      
//      playGameover();
//    SwingUtilities.invokeLater(new Runnable()
//    {
//      public void run()
//      {
//        String name = JOptionPane.showInputDialog("Game Over! ");
//        gf.setVisible(false);
//        sf.setVisible(true);
//        //lf.addPlayer(name);
//        
//      }
//    });
//     
//  }
  
  public static void gameOver(int score1, int score2) {
    playGameover(); // Play game over sound

    SwingUtilities.invokeLater(new Runnable() {
        public void run() {
            // Show Game Over message dialog without input
//            JOptionPane.showMessageDialog(null, "Game Over!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
//            
//            // Hide the game window
//            gf.setVisible(false);
//            sf.setVisible(true);
            if(score1 > score2)
            {    
                JOptionPane.showMessageDialog(null, "PLAYER 1 WON!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
            }
            if(score1 < score2)
            {
                JOptionPane.showMessageDialog(null, "PLAYER 2 WON!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
            }
            if(score1 == score2)
            {
                JOptionPane.showMessageDialog(null, "GAME DRAW!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
            }
            
            lf.loadLeaderboardFromFile();
            
            String name1 = JOptionPane.showInputDialog("Player 1 , enter your name:");
            String name2 = JOptionPane.showInputDialog("Player 2 , enter your name:");
            
            if (name1 != null && !name1.isEmpty()) {
                lf.addPlayer(name1, score1); // Add Player 1's score to the leaderboard
            }
            
            if (name2 != null && !name2.isEmpty()) {
                lf.addPlayer(name2, score2); // Add Player 2's score to the leaderboard
            }

            // Hide the game frame and show the leaderboard
            gf.setVisible(false);
            // Assuming gf is the game frame
            lf.setVisible(true);   // Assuming lf is the leaderboard frame
        }
    });
}

  
  
  
  
  
  public static void playClear()
  {
      audio.playClearLine();
  }
  public static void playGameover()
  {
      audio.playGameOver();
  }
  
  
  public static void main(String[] args)
  {
    java.awt.EventQueue.invokeLater(new Runnable()
    {
        public void run()
        {
          gf = new GameForm2();
//          sf = new StartupUI();
          sf = new StartupForm();
          lf = new LeaderboardForm();

          sf.setVisible(true);
        }
    }); 
  }
}
