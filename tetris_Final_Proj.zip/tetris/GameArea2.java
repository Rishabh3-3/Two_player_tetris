
package tetris;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

import javax.swing.JPanel;
import javax.swing.border.LineBorder;

public class GameArea2 extends JPanel
{
  private int gridRows;
  private int gridColumns;
  private int gridCellSize;
  private Color[][] background;

  private  TetrisBlocks2 block;

  public void spawnBlock()
  {
    Random r = new Random();
    int c = r.nextInt(7)+1;
    int[][] shapeO = new int[][]{{1,1}, {1,1}};
    int[][] shapeI = new int[][]{{1,1,1,1}};
    int[][] shapeJ = new int[][]{{0,1}, {0,1},{1,1}};
    int[][] shapeL = new int[][]{{1,0}, {1,0},{1,1}};
    int[][] shapeS = new int[][]{{0,1,1}, {1,1,0}};
    int[][] shapeT = new int[][]{{1,1,1}, {0,1,0}};
    int[][] shapeZ = new int[][]{{1,1,0}, {0,1,1}};

    switch (c) {
      case 1: block = new TetrisBlocks2(shapeO);
              block.spawn(gridColumns);
              break;
      case 2: block = new TetrisBlocks2(shapeI);
              block.spawn(gridColumns);
              break;
      case 3: block = new TetrisBlocks2(shapeJ);
              block.spawn(gridColumns);
              break;
      case 4: block = new TetrisBlocks2(shapeL);
              block.spawn(gridColumns);
              break;
      case 5: block = new TetrisBlocks2(shapeS);
              block.spawn(gridColumns);
              break;
      case 6: block = new TetrisBlocks2(shapeT);
              block.spawn(gridColumns);
              break;
      case 7: block = new TetrisBlocks2(shapeZ);
              block.spawn(gridColumns);
              break;
    }  
  }

  public boolean isBlockOutOfBounds(){
    if(block.getY()< 0)
    {
      //block=null;
      return true;
    }
    else{
      return false;
    }
  }
  
  public void turnBlockNull()
  {
      if(isBlockOutOfBounds())
      {
          block = null;
      }
  }

  public boolean moveBlockDown()
  {
    if(checkBottom() == false)
    {
      return false;
    }
    else
    {
      block.moveDown();
      repaint();
      return true;
    }
  }

  public boolean checkLeft(){
    if(block.getLeftEdge() <= 0)
    {
      return false;
    }
    else
    {
      int[][] shape = block.getShape();
      int w = block.getWidth();
      int h = block.getHeight();

      for (int row =0; row<h;row++)
      {
        for(int col = 0 ; col < w; col++)
        {
          if(shape[row][col] != 0)
          {
            int x = col + block.getX()-1;
            int y = row + block.getY();

            if (y < 0)
            {
              break;
            }
            if (background[y][x] != null)
            {
              return false;
            }
          }
        }
      }
      return true;
    }
  }

  public boolean checkRight(){
    if(block.getRightEdge() >= 10){
      return false;
    } 
    else 
    {
      int[][] shape = block.getShape();
      int w = block.getWidth();
      int h = block.getHeight();

      for (int row =0; row<h;row++)
      {
        for(int col = w-1 ; col >= 0; col--)
        {
          if(shape[row][col] != 0)
          {
            int x = col + block.getX()+1;
            int y = row + block.getY();

            if (y < 0)
            {
              break;
            }
            if (background[y][x] != null)
            {
              return false;
            }
          }
        }
      }
      return true;
    }
  }

  public boolean checkBottom(){
    if(block.getY() + block.getHeight() >= gridRows)
    {
      return false;
    }
    else
    {
      int[][] shape = block.getShape();
      int w = block.getWidth();
      int h = block.getHeight();

      for (int col =0; col<w;col++)
      {
        for(int row = 0 ; row < h; row++)
        {
          if(shape[row][col] != 0)
          {
            int x = col + block.getX();
            int y = row + block.getY()+1;

            if (y < 0 || y >= gridRows )
            {
              break;
            }
            if (background[y][x] != null)
            {
              return false;
            }
          }
        }
      }
      return true ;
    }
  }  

  public void moveBlockRight()
  {
    if(block == null) return ;

    if(checkRight() == false)
    {
      return;
    }
    else
    {
      block.moveRight();
      repaint();
    }
  }

  public void moveBlockLeft()
  {
    if(block == null) return ;

    if(checkLeft() == false)
    {
      return;
    }
    else
    {
      block.moveLeft();
      repaint();
    }
  }

  public void rotateBlock()
  {
      
      if(block == null)
      {
          return;
      }
      
      int [][] originalShape = block.getShape();
      int originalX = block.getX();
      int originalY = block.getY();
      
      block.rotate(originalShape,originalX,originalY,background);
      
      repaint();
//    if(block == null) return ;
//
//    block.rotate();// Implement block rotation logic here
//    repaint();
  }
  
//  public boolean isBlockPositionValid(int[][] shape) {
//    // Check if the block is within bounds and not overlapping
//    for (int row = 0; row < block.getHeight(); row++) {
//        for (int col = 0; col < block.getWidth(); col++) {
//            if (block.getShape()[row][col] != 0) {
//                int x = block.getX() + col;
//                int y = block.getY() + row;
//
//                // Check for bounds
//                if (x < 0 || x >= gridColumns || y < 0 || y >= gridRows) {
//                    return false; // Out of bounds
//                }
//
//                // Check for overlapping blocks
//                if (background[y][x] != null) {
//                    return false; // Collision with existing blocks
//                }
//            }
//        }
//    }
//    return true; // Valid position
//}
  


  public void dropBlock()
  {
    if(block == null) return ;
    
    if(checkBottom() == false)
    {
      moveTOBackground();
    }
    else
    {
      block.moveDown();
      repaint();
    }
  }

  public int clearLines()
  {
    boolean filledLine;
    int linesCleared = 0;

    for(int r = gridRows-1 ; r >= 0 ; r--)
    {
      filledLine = true;
      for(int c = 0; c < gridColumns; c++)
      {
        if(background[r][c] == null)
        {
          filledLine = false;
          break;
        }
      }
      if(filledLine)
      {
        linesCleared ++;
        for(int i=0; i<gridColumns; i++)
        {
          background[r][i] = null;
        }

        for(int j = r; j > 0; j--)
        {
          for(int i = 0; i < gridColumns; i++)
          {
            background[j][i] = background[j-1][i];
            background[j-1][i] = null;
          }
        }
        r++;
        repaint();
      }
    }
    
    
    if(linesCleared > 0)
    {
        Tetris2.playClear();
    }
    return  linesCleared;
  }

  public void moveTOBackground()
  {
    int [][] shape = block.getShape();
    int h = block.getHeight();
    int w = block.getWidth();

    int xPos = block.getX();
    int yPos = block.getY();

    Color color = block.getColor();

    for(int r=0; r< h ;r++)
    {
      for(int c=0;c<w;c++)
      {
        if(shape[r][c]== 1)
        {
          int newX = c+xPos;
          int newY = r+yPos;
          newX = Math.max(0, newX);
          newX = Math.min(gridColumns - 1, newX);
          newY = Math.max(0, newY);
          newY = Math.min(gridRows - 1, newY);
          background[newY][newX] = color; 

        }
      }
    }
  }

  private void drawBlock(Graphics g)
  {
    for(int x = 0; x< block.getHeight(); x++)
    {
      for(int y = 0; y < block.getWidth(); y++ )
      {
        if(block.getShape()[x][y]==1)
        {

          int  a =block.getX();
          int b=block.getY();
            g.setColor(block.getColor());
            g.fillRect(((y+a)*gridCellSize), (x+b)*gridCellSize ,gridCellSize, gridCellSize);
            g.setColor(Color.black);
            g.drawRect(((y+a)*gridCellSize), (x+b)*gridCellSize ,gridCellSize, gridCellSize);
        }
      }
    }
  }

  private void drawBackground(Graphics g)
  {
    for(int r = 0; r < gridRows; r++)
    {
      for(int c = 0; c< gridColumns; c++ )
      {
        if(background[r][c] != null)
        {
          int x = c* gridCellSize;
          int y = r* gridCellSize;
          g.setColor(background[r][c]);
          g.fillRect(x, y ,gridCellSize, gridCellSize);
          g.setColor(Color.black);
          g.drawRect(x, y ,gridCellSize, gridCellSize);
        }
      }
    }
  }
  
  public GameArea2(int columns)
  {
    this.setBackground(Color.cyan);
    this.setBorder(new LineBorder(Color.blue, 5));
    
    gridColumns = columns;
    gridCellSize = 50;//this.getBounds().width / gridColumns;
    gridRows =  (750/gridCellSize);//this.getBounds().height / gridCellSize;
    background = new Color[gridRows][gridColumns];
    for(int r = 0; r < gridRows; r++)
    {
      for(int c = 0; c < gridColumns; c++)
      {
        background[r][c] = null;
      }
    }
    
    setDoubleBuffered(true);
  }
  @Override
  protected void paintComponent(Graphics g)
  {
    super.paintComponent(g);
    
     gridCellSize = Math.min(this.getWidth() / gridColumns, this.getHeight() / gridRows);

    
    
    for(int j= 0; j< gridRows; j++)
    {
      for(int x = 0; x < gridColumns; x++)
      {
        g.setColor(Color.black);
        g.fillRect((x*gridCellSize),j*gridCellSize ,gridCellSize, gridCellSize);
        g.setColor(Color.white);
        g.drawRect((x*gridCellSize),j*gridCellSize ,gridCellSize, gridCellSize);
        
      }
    }

    drawBackground(g);
    drawBlock(g);

  }
  
  public void resetGrid() {
      for (int r = 0; r < gridRows; r++) {
          for (int c = 0; c < gridColumns; c++) {
              background[r][c] = null;  // Clear the background
          }
      }
      repaint();  // Repaint the area to reflect the cleared grid
  }
  
   @Override
    public boolean isDoubleBuffered() {
        return true;
    }
}
