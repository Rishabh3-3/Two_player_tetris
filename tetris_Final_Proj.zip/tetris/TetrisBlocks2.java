
package tetris;


import java.awt.Color;
import java.util.Random;

public class TetrisBlocks2
{
  private int[][] shape ;
  
  private Color color;
  private int x, y;
  private int[][][] shapes;
  private int currentRotation;
  private Color[] availableColors = {
    Color.BLUE,
    Color.CYAN,
    Color.GREEN,
    Color.MAGENTA,
    Color.ORANGE,
    Color.PINK,
    Color.RED,
    Color.WHITE,
    Color.YELLOW}; 

  public TetrisBlocks2(int[][] shape )
  {
    this.shape = shape;

    initShapes();
  }

  private void initShapes()
  {
    shapes = new int[4][][];

    for(int i = 0; i< 4;i++)
    {
      int r = shape[0].length;
      int c = shape.length;

      shapes[i]  = new int [r][c];

      for(int y = 0; y< r;y++)
      {
        for(int x = 0 ; x < c;x++)
        {
          shapes[i][y][c-x-1] = shape[x][y];
        }
      }
      shape = shapes[i];
    }
  }

  public void spawn(int gridWidth)
  {
    Random r = new Random();

    currentRotation = r.nextInt(4);
    shape = shapes[currentRotation];
    y = -getHeight();
    x = r.nextInt(gridWidth-getWidth());
    color = availableColors[r.nextInt(availableColors.length)];

    
  }
 
  public int[][] getShape(){
    return shape;
  }

  public Color getColor(){
    return  color;
  }

  public int getHeight(){
    return shape.length;
  }

  public int getWidth(){
    return shape[0].length;
  }

  public int getX(){
    return x;
  }

  public int getY() {
      return y;
  }

  public void moveDown(){
    y++;
  }


  public void moveLeft(){
    x--;
  }

  public void moveRight(){
    x++;
  }

  public void rotate(int[][] originalShape ,int X, int Y, Color[][] palatte)
  {
      //int[][] finalShape;
    currentRotation++;
    if(currentRotation > 3 )
    {
        currentRotation = 0;
    }
    int [][] rotatedShape = shapes[currentRotation];
    
    int validationResult = isBlockPositionValid(rotatedShape,X, Y ,palatte);
     if(validationResult == 0)
     {
         shape = rotatedShape;
         x = X;
         y = Y;
     }
     
     else if(validationResult == 1)//2)
     {
         int newX = X;
         int newWidth = rotatedShape[0].length;
         //finalShape = originalShape;
         
         if (newX + newWidth > 10) {
            // Adjust the position so it stays within bounds
            newX = 10 - newWidth;
        }
         
        shape = rotatedShape;
        x = newX;
        y = Y;
     }
     
     else if(validationResult == 2)
     {
        shape = originalShape;
     }

  }
  
    private int isBlockPositionValid(int[][] shape,int shapeX, int shapeY, Color[][] palatte) 
            
    {
        
        //Random r = new Random();
    // Check if the block is within bounds and not overlapping
    for (int row = 0; row < shape.length; row++) {
        for (int col = 0; col < shape[0].length; col++) {
            if (shape[row][col] != 0) {
                
                int x = shapeX + col;
                int y = shapeY + row;

                // Check for bounds
                if (x < 0 || x >= 10 || y < 0 || y >= 15) {
                    return 1; // Out of bounds
                }

                // Check for overlapping blocks
                if (palatte[y][x] != null) {
                    return 2; // Collision with existing blocks
                }
            }
        }
    }
    return 0; // Valid position
}

  public int getBottomEdge(){
    return y + getHeight();
  }

  public int getLeftEdge(){
    return getX();
  }

  public int getRightEdge(){
    return (getX()+shape[0].length);
  }
}
