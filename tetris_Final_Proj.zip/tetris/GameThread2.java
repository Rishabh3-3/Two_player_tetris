
package tetris;

import java.util.logging.Level;
import java.util.logging.Logger;

public class GameThread2  extends Thread
{
  private GameArea2 ga;
  private GameForm2 gf;
  private int score = 0;
  private int level=1;
  private int scorePerLevel = 3;
  private int pause = 750;
  private int speedupPerlevel= 100;

  private static final Logger logger = Logger.getLogger(GameThread2.class.getName());
  public GameThread2(GameArea2 ga, GameForm2 gf)
  {
    this.ga = ga;
    this.gf = gf;
    this.score=0;
    //gf.updateScore(score, ga);
  }

  @Override
  public void run()
  {
    while(true)
    {

      ga.spawnBlock();

      while(ga.moveBlockDown()== true)
      {
        try
        {
          
          Thread.sleep(pause);
        }
        catch (InterruptedException ex)
        {
            return;
          //logger.log(Level.SEVERE, "Thread interrupted", ex);
        }
      }

//      if(ga.isBlockOutOfBounds())
//      {
//        gf.StoppingThread(); 
//        Tetris2.gameOver();
//        ga.turnBlockNull();
//        
//        break;
//      }
      
      ga.moveTOBackground();
      int cleared  = ga.clearLines();
      this.score = cleared;
      if(cleared != 0)
      {
        gf.updateScore(this.score, ga);
      }
      
      if(ga.isBlockOutOfBounds())
      {
        gf.StoppingThread(); 
        
        //Tetris2.gameOver(score);
        
        gf.whichGameOver(score, ga);
        ga.turnBlockNull();
        System.out.println("Game Over for player with gamearea : "+ ga);
        break;
      }
      //System.out.println("Score = "+score+" Number of lines cleared : "+ cleared+" for gameArea : "+ga);
      
       //System.out.println("Thread for " + ga + " updating score to " + score);
      
      
      
//      if(score >= level*scorePerLevel)
//      {
//          level++;
//          pause = Math.max(100, pause-speedupPerlevel);
//      }
//        //pause = pause - speedupPerlevel;
      
      
    }
  }
}

